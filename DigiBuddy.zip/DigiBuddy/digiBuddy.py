import tkinter as tk
from tkinter import messagebox, simpledialog, scrolledtext
from PIL import Image, ImageTk
import random
import speech_recognition as sr

# Knowledge Base
faq_answers = {
    "browser": "A browser is a tool to visit websites, like Google Chrome or Safari.",
    "gmail": "Go to gmail.com, click 'Create account', fill in details, and you’re done!",
    "email": "An email is like a letter you send and receive online.",
    "whatsapp": "Install WhatsApp, verify your number, and start messaging friends.",
    "pay bills": "Use your bank or payment app to select biller, enter details, and pay.",
    "wifi": "Go to Wi-Fi settings, pick your network, and type the password to connect.",
    "screenshot": "Press Power + Volume Down (on most phones) to take a screenshot."
}

help_topics = [
    "Can't connect to internet? Restart Wi-Fi or router.",
    "Phone not charging? Try another cable or clean charging port.",
    "App keeps crashing? Update or reinstall the app.",
]

tutorials = [
    "To install an app: Open Play Store > Search app > Click Install.",
    "To set alarm: Open Clock app > Tap '+' > Set time > Save.",
    "To join a video call: Open the app (like Zoom), enter Meeting ID, click Join.",
]

safety_rules = [
    "Never share your OTP with anyone.",
    "Avoid clicking links from unknown messages.",
    "Use strong passwords and don't reuse them.",
]

tech_tips = [
    "Always double-check websites before entering personal info!",
    "Use strong passwords like: MyDog$1234 instead of '1234'",
    "Update your phone and apps regularly to stay safe.",
    "Take backups of important photos and documents."
]

tip_index = 0

# Response Generator
def get_simple_response(query):
    for keyword, answer in faq_answers.items():
        if keyword in query.lower():
            return answer
    return "That's a good question! I’ll try to simplify: Think of it like asking a friend. 😊"

# Send button
def send_message():
    user_input = user_entry.get()
    if not user_input.strip():
        return
    chat_log.insert(tk.END, f"You: {user_input}\n", "user")
    response = get_simple_response(user_input)
    chat_log.insert(tk.END, f"DigiBuddy: {response}\n\n", "bot")
    user_entry.delete(0, tk.END)

# Learn Basics
def show_basics():
    basic_list = "\n".join(f"- {q.capitalize()}" for q in faq_answers.keys())
    choice = simpledialog.askstring("Learn Basics", f"Choose a topic:\n\n{basic_list}")
    if choice:
        send_custom_message(choice)

# Tech Tips
def show_tip():
    global tip_index
    tip = tech_tips[tip_index % len(tech_tips)]
    tip_index += 1
    chat_log.insert(tk.END, f"DigiBuddy: Tech Tip – {tip}\n\n", "bot")

# Voice Input
def voice_input():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        try:
            chat_log.insert(tk.END, "DigiBuddy: Listening... 🎤\n", "bot")
            audio = recognizer.listen(source, timeout=5)
            query = recognizer.recognize_google(audio)
            user_entry.delete(0, tk.END)
            user_entry.insert(0, query)
            send_message()
        except:
            chat_log.insert(tk.END, "DigiBuddy: Sorry, I couldn't understand. Try again. 🎧\n\n", "bot")

# Help Topics
def show_help():
    msg = "\n".join(help_topics)
    chat_log.insert(tk.END, f"DigiBuddy: Help Center:\n{msg}\n\n", "bot")

# Tutorials
def show_tutorials():
    msg = "\n".join(tutorials)
    chat_log.insert(tk.END, f"DigiBuddy: Tutorials:\n{msg}\n\n", "bot")

# Online Safety
def show_safety():
    msg = "\n".join(safety_rules)
    chat_log.insert(tk.END, f"DigiBuddy: Stay Safe Online:\n{msg}\n\n", "bot")

# Custom Message
def send_custom_message(text):
    chat_log.insert(tk.END, f"You: {text}\n", "user")
    response = get_simple_response(text)
    chat_log.insert(tk.END, f"DigiBuddy: {response}\n\n", "bot")

# Tkinter UI
root = tk.Tk()
root.title("DigiBuddy - Your Friendly Guide to the Digital World")
root.geometry("720x640")

# Background Image
bg_img = Image.open("background.png")
bg_img = bg_img.resize((720, 640))
bg_photo = ImageTk.PhotoImage(bg_img)
bg_label = tk.Label(root, image=bg_photo)
bg_label.place(relwidth=1, relheight=1)

# Header Label
header = tk.Label(root, text="DigiBuddy – Your Friendly Guide to the Digital World",
                  font=("Helvetica", 18, "bold"), bg="#c0e9ff", fg="#003366")
header.place(x=0, y=0, width=720, height=40)

# Chat Log
chat_log = scrolledtext.ScrolledText(root, wrap=tk.WORD, font=("Arial", 14), bg="white", fg="black")
chat_log.place(x=30, y=50, width=660, height=400)
chat_log.tag_config("user", foreground="blue", font=("Arial", 14, "bold"))
chat_log.tag_config("bot", foreground="green", font=("Arial", 14, "italic"))

# Entry Field
user_entry = tk.Entry(root, font=("Arial", 14))
user_entry.place(x=30, y=470, width=500, height=40)

# Buttons
tk.Button(root, text="Send", command=send_message, font=("Arial", 12), bg="#4CAF50", fg="white").place(x=540, y=470, width=70, height=40)
tk.Button(root, text="🎤 Voice", command=voice_input, font=("Arial", 12), bg="#607D8B", fg="white").place(x=620, y=470, width=70, height=40)

tk.Button(root, text="Learn Basics", command=show_basics, font=("Arial", 12), bg="#2196F3", fg="white").place(x=30, y=530, width=150, height=40)
tk.Button(root, text="Tech Tips", command=show_tip, font=("Arial", 12), bg="#FF9800", fg="white").place(x=200, y=530, width=150, height=40)
tk.Button(root, text="Get Help", command=show_help, font=("Arial", 12), bg="#9C27B0", fg="white").place(x=370, y=530, width=150, height=40)
tk.Button(root, text="Tutorials", command=show_tutorials, font=("Arial", 12), bg="#00BCD4", fg="white").place(x=540, y=530, width=150, height=40)
tk.Button(root, text="Online Safety", command=show_safety, font=("Arial", 12), bg="#F44336", fg="white").place(x=280, y=580, width=160, height=40)

root.mainloop()
